#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"
#include "procinfo.h"

int stdout = 1;

void
getprocsinfotest(){
  struct procinfo info[64];
  int procnum = getprocsinfo(info);
  if(procnum < 0)
  {
    printf(stdout,"test case failed");
	exit();
  }
  else{
	printf(stdout, "processes:%d\n", procnum);

	struct procinfo *in;
  	for(in = info; in < &info[procnum]; in++)
    {
	  printf(stdout, "pid:%d, name:%s\n", in->pid, in->pname);
    }
	exit();
  }
}


int
main(int argc, char *argv[])
{
  printf(1, "testgetprocsinfo starting\n");
  getprocsinfotest();
  exit();
}