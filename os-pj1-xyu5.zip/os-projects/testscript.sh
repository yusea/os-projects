#!/bin/bash

make qemu-nox <<< $'ls\n'
