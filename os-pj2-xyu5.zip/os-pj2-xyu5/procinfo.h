// procinfo structure

struct procinfo {
    int pid;
    char pname[16];
};